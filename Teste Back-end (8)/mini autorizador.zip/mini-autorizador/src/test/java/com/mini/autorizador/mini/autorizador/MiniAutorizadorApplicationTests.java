package com.mini.autorizador.mini.autorizador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniAutorizadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
